extends Node2D
## M1 illustrated visual room with real player movement and mobile controls.
## Source room image retains some painted-in furniture; main M1 asset quality remains pending engine & device QA.
@onready var player: CharacterBody2D = $World/Player
@onready var world: Node2D = $World
@onready var bed_foreground: Sprite2D = $World/BedForeground
var ui: Control
var objective: Label
var info: Label
var hint: Label
var item_label: Label
var portrait_caption: Label
var run_button: Button
var stick: Control
var focus_marker: Sprite2D
var screen_flash: ColorRect
var scare_image: TextureRect
var scare_sound: AudioStreamPlayer
var has_phone: bool = false
var inspected_mirror: bool = false
var has_note: bool = false
var horror_seen: bool = false
var ending: bool = false
var reduce_flash: bool = true
var dialog_timer: float = 0.0
var scare_timer: float = 0.0
const INTERACT_RANGE: float = 85.0
const W: float = 1280.0
const H: float = 720.0
var hotspots: Dictionary = {
    "phone": Vector2(615, 286),
    "mirror": Vector2(796, 372),
    "note": Vector2(506, 440),
    "bed": Vector2(660, 417),
    "wardrobe": Vector2(488, 552),
    "exit": Vector2(801, 681)
}
var hotspot_names: Dictionary = {
    "phone": "桌上的手机", "mirror": "镜子", "note": "纸条",
    "bed": "床铺", "wardrobe": "衣柜", "exit": "门口"
}

func _ready() -> void:
    _install_collisions()
    _create_lighting()
    _make_ui()
    _create_scare_layers()
    _say("02:17。你听见一声敲击——来自没有门的那面墙。\n先检查手机与镜子。", 8.0)

func _process(delta: float) -> void:
    if dialog_timer > 0.0:
        dialog_timer -= delta
        if dialog_timer <= 0.0 and not ending:
            info.text = "靠近物品后，点击调查。"
    if Input.is_action_just_pressed("interact"):
        investigate()
    bed_foreground.visible = player.global_position.y < 655.0
    _update_focus()
    if scare_timer > 0.0:
        scare_timer -= delta
        var updated_color: Color = screen_flash.color
        updated_color.a = (0.22 if reduce_flash else 0.49) * min(1.0, scare_timer * 2.8)
        screen_flash.color = updated_color
        if scare_timer <= 0.0:
            scare_image.visible = false
            screen_flash.visible = false
            player.set("controls_locked", false)

func _say(message: String, seconds: float = 4.0) -> void:
    info.text = message
    dialog_timer = seconds

func _install_collisions() -> void:
    # Player circle + actual physics bodies, not apparent rectangles painted on an image.
    var solids := [
        [Vector2(371, 360), Vector2(22, 720)],
        [Vector2(909, 360), Vector2(22, 720)],
        [Vector2(639, 2), Vector2(540, 16)],
        [Vector2(639, 718), Vector2(540, 16)],
        [Vector2(611, 215), Vector2(230, 119)],  # desk & chair
        [Vector2(631, 548), Vector2(159, 270)],  # central bed
        [Vector2(437, 251), Vector2(78, 275)],   # left shelving
        [Vector2(861, 241), Vector2(68, 325)],   # right wardrobe/shelving
        [Vector2(449, 559), Vector2(71, 204)]    # near entry cabinet
    ]
    for record in solids:
        var body := StaticBody2D.new()
        body.position = record[0]
        var shape := RectangleShape2D.new()
        shape.size = record[1]
        var collision := CollisionShape2D.new()
        collision.shape = shape
        body.add_child(collision)
        world.add_child(body)

func _create_lighting() -> void:
    # Keep baked painting legible: never reintroduce an almost-black default screen.
    var ambient := CanvasModulate.new()
    ambient.color = Color(0.95, 0.94, 0.96)
    add_child(ambient)
    for spec in [[Vector2(542, 177), Color(0.67, 0.80, 1.0)],
                 [Vector2(806, 246), Color(1.0, 0.68, 0.45)]]:
        var light := PointLight2D.new()
        light.position = spec[0]
        light.texture = preload("res://assets/glow.png")
        light.texture_scale = 2.15
        light.color = spec[1]
        light.energy = 0.28
        add_child(light)

func _label(txt: String, size: int, color: Color) -> Label:
    var lab := Label.new()
    lab.text = txt
    lab.add_theme_color_override("font_color", color)
    lab.add_theme_font_size_override("font_size", size)
    lab.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return lab

func _style(bg: Color, border: Color) -> StyleBoxFlat:
    var st := StyleBoxFlat.new()
    st.bg_color = bg
    st.border_color = border
    st.set_border_width_all(2)
    st.set_corner_radius_all(8)
    st.content_margin_left = 14.0
    st.content_margin_right = 14.0
    st.content_margin_top = 8.0
    st.content_margin_bottom = 8.0
    return st

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 15
    add_child(layer)
    ui = Control.new()
    ui.set_anchors_preset(Control.PRESET_FULL_RECT)
    ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(ui)

    var logo := _label("夜 幕 之 下", 33, Color("f3e2cf"))
    logo.position = Vector2(23, 16)
    ui.add_child(logo)
    var sub := _label("N I G H T F A L L   /   02:17", 14, Color("bea6a3"))
    sub.position = Vector2(23, 63)
    ui.add_child(sub)
    portrait_caption = _label("澪   ·   不要回头", 23, Color("eadad2"))
    portrait_caption.position = Vector2(22, 456)
    ui.add_child(portrait_caption)
    var mission := _label("探索记录", 22, Color("f1d9c3"))
    mission.position = Vector2(933, 27)
    ui.add_child(mission)
    objective = _label("寻找房间中的异常\n调查手机与镜子", 20, Color("d5c4b8"))
    objective.position = Vector2(932, 108)
    objective.size = Vector2(316, 68)
    ui.add_child(objective)
    var group := _label("调查记录", 21, Color("e9d6c8"))
    group.position = Vector2(935, 193)
    ui.add_child(group)
    info = _label("", 20, Color("e9dcd2"))
    info.position = Vector2(936, 232)
    info.size = Vector2(305, 193)
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    ui.add_child(info)
    item_label = _label("线索  0 / 2", 19, Color("cdb9b2"))
    item_label.position = Vector2(935, 473)
    ui.add_child(item_label)
    hint = _label("WASD 移动 · E 调查\n手机摇杆 / 调查按钮", 16, Color("b7a9a6"))
    hint.position = Vector2(936, 524)
    hint.size = Vector2(314, 56)
    ui.add_child(hint)

    stick = Control.new()
    stick.set_script(preload("res://scripts/virtual_stick.gd"))
    stick.position = Vector2(28, 517)
    stick.size = Vector2(180, 180)
    ui.add_child(stick)
    stick.connect("moved", Callable(self, "_on_stick_moved"))
    run_button = _add_button("奔跑", Vector2(1020, 610), Vector2(94, 86))
    run_button.button_down.connect(_on_run_down)
    run_button.button_up.connect(_on_run_up)
    var investigate_button := _add_button("调查", Vector2(1140, 590), Vector2(111, 106))
    investigate_button.pressed.connect(investigate)
    var access_button := _add_button("减弱闪烁：开", Vector2(919, 577), Vector2(204, 31))
    access_button.add_theme_font_size_override("font_size", 14)
    access_button.pressed.connect(func():
        reduce_flash = not reduce_flash
        access_button.text = "减弱闪烁：开" if reduce_flash else "减弱闪烁：关")

    focus_marker = Sprite2D.new()
    focus_marker.texture = preload("res://assets/v2/interact_mark.png")
    focus_marker.visible = false
    focus_marker.z_index = 8
    add_child(focus_marker)

func _add_button(txt: String, pos: Vector2, dims: Vector2) -> Button:
    var button := Button.new()
    button.text = txt
    button.position = pos
    button.size = dims
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", 22)
    button.add_theme_color_override("font_color", Color("f3dfcc"))
    button.add_theme_stylebox_override("normal", _style(Color(0.10,0.13,0.19,0.89),Color(0.52,0.40,0.39,0.85)))
    button.add_theme_stylebox_override("pressed", _style(Color(0.32,0.19,0.19,0.92),Color(0.93,0.72,0.61,1.0)))
    ui.add_child(button)
    return button

func _create_scare_layers() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 25
    add_child(layer)
    scare_image = TextureRect.new()
    scare_image.texture = preload("res://assets/v2/scare_closeup.png")
    scare_image.position = Vector2(368, 0)
    scare_image.size = Vector2(545, 720)
    scare_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    scare_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    scare_image.mouse_filter = Control.MOUSE_FILTER_IGNORE
    scare_image.visible = false
    layer.add_child(scare_image)
    screen_flash = ColorRect.new()
    screen_flash.position = Vector2.ZERO
    screen_flash.size = Vector2(W, H)
    screen_flash.color = Color(0.52, 0.07, 0.09, 0.20)
    screen_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
    screen_flash.visible = false
    layer.add_child(screen_flash)
    scare_sound = AudioStreamPlayer.new()
    scare_sound.stream = preload("res://assets/v2/scare_stinger.wav")
    scare_sound.volume_db = -13.0
    add_child(scare_sound)

func _update_focus() -> void:
    var nearest := _nearest_hotspot()
    if nearest.is_empty():
        focus_marker.visible = false
    else:
        focus_marker.visible = true
        focus_marker.global_position = hotspots[nearest] + Vector2(0,-35)

func _nearest_hotspot() -> String:
    var closest := ""
    var best := INTERACT_RANGE
    for key in hotspots:
        var dist: float = player.global_position.distance_to(hotspots[key])
        if dist < best:
            best = dist
            closest = key
    return closest

func investigate() -> void:
    if ending:
        get_tree().reload_current_scene()
        return
    if scare_timer > 0.0:
        return
    var nearest := _nearest_hotspot()
    if nearest.is_empty():
        _say("附近没有可以调查的东西。", 2.3)
        return
    match nearest:
        "phone":
            has_phone = true
            item_label.text = "线索  %d / 2" % [int(has_phone) + int(has_note)]
            _say("手机屏幕亮着。02:17，一条来自自己的消息：\n『镜子里少了一个人。』", 7.0)
        "mirror":
            if not inspected_mirror:
                inspected_mirror = true
                _say("倒影迟了半秒才抬头。\n你明明没有笑，镜中的嘴角却上扬了。", 7.0)
            elif has_phone and has_note and not horror_seen:
                horror_seen = true
                _trigger_scare()
            else:
                _say("镜面冷得像一扇没关严的窗。", 5.0)
        "note":
            has_note = true
            item_label.text = "线索  %d / 2" % [int(has_phone) + int(has_note)]
            _say("一张被水浸湿的便签：\n『不要把自己的倒影留在房间里。』", 6.0)
        "bed":
            _say("被子被人小心地折过。床沿还有另一人的体温。", 5.0)
        "wardrobe":
            _say("衣柜里挂着一件湿透的外套。尺码和你的一模一样。", 5.0)
        "exit":
            if horror_seen:
                ending = true
                objective.text = "M1 视觉关卡完成\n点击调查重新进入"
                _say("你走向房门。房间里忽然传来自己的声音：\n『你终于肯把我留下了。』\n\n——本次美术试玩片段结束。", 9999.0)
            else:
                _say("门把手纹丝不动。\n你还没有弄清房间里发生了什么。", 5.0)

func _trigger_scare() -> void:
    scare_timer = 0.72
    scare_image.visible = true
    screen_flash.visible = true
    player.set("controls_locked", true)
    scare_sound.play()
    objective.text = "离开这里！\n去房间右下角出口"
    _say("那张脸猛地贴上镜面。\n可怕的是——它的眼睛和你一模一样。", 8.0)

func _on_stick_moved(direction: Vector2) -> void:
    player.set("touch_direction", direction)

func _on_run_down() -> void:
    player.set("touch_running", true)

func _on_run_up() -> void:
    player.set("touch_running", false)
