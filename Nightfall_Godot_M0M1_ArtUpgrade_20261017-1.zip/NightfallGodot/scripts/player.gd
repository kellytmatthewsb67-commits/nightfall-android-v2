extends CharacterBody2D
## Illustrated sprite art, character feet align with physical collision body.
@export var walk_speed: float = 136.0
@export var run_speed: float = 216.0
var touch_direction: Vector2 = Vector2.ZERO
var touch_running: bool = false
var controls_locked: bool = false
var facing: String = "front"
var _elapsed: float = 0.0
var _step: int = 0
var _frames: Dictionary = {}
@onready var sprite: Sprite2D = $Sprite

func _ready() -> void:
    _install_input_actions()
    for direction in ["front", "back", "left", "right"]:
        var frames: Array[Texture2D] = []
        for i in range(4):
            frames.append(load("res://assets/v2/hero_%s_%d.png" % [direction, i]))
        _frames[direction] = frames
    _apply_frame()

func _physics_process(delta: float) -> void:
    var keys: Vector2 = Input.get_vector("move_left", "move_right", "move_up", "move_down")
    var axis: Vector2 = keys if keys.length_squared() > 0.01 else touch_direction
    if controls_locked:
        axis = Vector2.ZERO
    axis = axis.limit_length(1.0)
    var running: bool = touch_running or Input.is_action_pressed("run")
    velocity = axis * (run_speed if running else walk_speed)
    move_and_slide()
    if axis.length_squared() > 0.01:
        if abs(axis.x) > abs(axis.y) * 1.12:
            facing = "right" if axis.x > 0.0 else "left"
        else:
            facing = "front" if axis.y > 0.0 else "back"
        _elapsed += delta
        if _elapsed >= (0.115 if running else 0.19):
            _elapsed = 0.0
            _step = (_step + 1) % 4
            _apply_frame()
    elif _step != 0:
        _step = 0
        _elapsed = 0.0
        _apply_frame()

func _apply_frame() -> void:
    if not _frames.is_empty():
        sprite.texture = _frames[facing][_step]

func _install_input_actions() -> void:
    var key_groups := {
        "move_left": [KEY_A, KEY_LEFT],
        "move_right": [KEY_D, KEY_RIGHT],
        "move_up": [KEY_W, KEY_UP],
        "move_down": [KEY_S, KEY_DOWN],
        "run": [KEY_SHIFT],
        "interact": [KEY_E]
    }
    for action in key_groups:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
        for key in key_groups[action]:
            var event := InputEventKey.new()
            event.physical_keycode = key
            InputMap.action_add_event(action, event)
