extends Control
## Virtual stick works with either touchscreen or mouse and exposes a vector.
signal moved(direction: Vector2)
const RADIUS: float = 65.0
var active_index: int = -1
var mouse_down: bool = false
var direction: Vector2 = Vector2.ZERO

func _ready() -> void:
    custom_minimum_size = Vector2(180, 180)
    mouse_filter = Control.MOUSE_FILTER_STOP
    queue_redraw()

func _draw() -> void:
    var mid := size / 2.0
    draw_circle(mid, 83.0, Color(0.035, 0.05, 0.08, 0.52))
    draw_arc(mid, 83.0, 0.0, TAU, 64, Color(0.78, 0.78, 0.77, 0.30), 2.0, true)
    draw_circle(mid + direction * RADIUS, 34.0, Color(0.60, 0.69, 0.74, 0.59))
    draw_arc(mid + direction * RADIUS, 34.0, 0.0, TAU, 32, Color(0.97, 0.92, 0.83, 0.60), 2.0, true)

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and active_index == -1:
            active_index = event.index
            _set_axis(event.position)
            accept_event()
        elif not event.pressed and event.index == active_index:
            active_index = -1
            _reset()
            accept_event()
    elif event is InputEventScreenDrag and event.index == active_index:
        _set_axis(event.position)
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        mouse_down = event.pressed
        if mouse_down:
            _set_axis(event.position)
        else:
            _reset()
        accept_event()
    elif event is InputEventMouseMotion and mouse_down:
        _set_axis(event.position)
        accept_event()

func _set_axis(local_point: Vector2) -> void:
    direction = ((local_point - size / 2.0) / RADIUS).limit_length(1.0)
    moved.emit(direction)
    queue_redraw()

func _reset() -> void:
    direction = Vector2.ZERO
    moved.emit(direction)
    queue_redraw()
