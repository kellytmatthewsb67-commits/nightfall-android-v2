"""Approximate 2D reachability of physics collision rectangles from main.gd.
Only tests approach paths; not a Godot physics simulation.
"""
from collections import deque
obstacles=[
 (360,0,382,720),(898,0,920,720),(369,-6,909,10),(369,710,909,726),
 (496,155,726,274), (551.5,413,710.5,683), (398,113.5,476,388.5),
 (827,78.5,895,403.5), (413.5,457,484.5,661)
]
start=(663,347)
targets={'phone':(615,286),'mirror':(796,372),'note':(506,440),
         'bed':(660,417),'wardrobe':(488,552),'exit':(801,681)}
step=7;radius=14;W,H=1280,720

def blocked(ix,iy):
    x=ix*step;y=iy*step
    return any(x+radius>a and x-radius<c and y+radius>b and y-radius<d for a,b,c,d in obstacles)
q=deque([(round(start[0]/step),round(start[1]/step))]); seen=set(q)
while q:
    x,y=q.popleft()
    for a,b in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
        if 0<=a<W//step and 0<=b<H//step and (a,b) not in seen and not blocked(a,b):
            seen.add((a,b));q.append((a,b))
assert len(seen)>1000,'Player trapped by collision bodies'
for label,(x,y) in targets.items():
    dist=min(((a*step-x)**2+(b*step-y)**2)**.5 for a,b in seen)
    print(f'{label}: nearest reachable approach {dist:.1f} px')
    assert dist<85,(label,dist)
print('STATIC REACHABILITY PASS:',len(seen),'reachable grid cells')
