extends SceneTree
## Godot import/runtime gate. Requires actual Godot; static checks are NOT equivalent.
## godot --headless --path . --script res://tests/smoke_test.gd
func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var packed: PackedScene = load("res://scenes/main.tscn")
    if packed == null:
        _fail("Main scene failed to load")
        return
    var game: Node = packed.instantiate()
    root.add_child(game)
    await process_frame
    var p: CharacterBody2D = game.get_node_or_null("World/Player")
    if p == null or p.get_node_or_null("Sprite") == null:
        _fail("Illustrated player node missing")
        return
    var start_position: Vector2 = p.global_position
    p.touch_direction = Vector2.RIGHT
    for i in range(12):
        await physics_frame
    p.touch_direction = Vector2.ZERO
    if p.global_position.distance_to(start_position) < 5.0:
        _fail("The player could not move")
        return
    # Teleport near reachable approach point for each hotspot (unit smoke, not pathfinding).
    p.global_position = Vector2(611, 307)
    game.investigate()
    if not game.has_phone:
        _fail("Phone interaction did not set flag")
        return
    p.global_position = Vector2(793, 371)
    game.investigate()
    if not game.inspected_mirror:
        _fail("Mirror interaction failed")
        return
    p.global_position = Vector2(506, 428)
    game.investigate()
    if not game.has_note:
        _fail("Note interaction failed")
        return
    p.global_position = Vector2(793, 371)
    game.investigate()
    if not game.horror_seen:
        _fail("Conditional scare was not triggered")
        return
    # Skip timed overlay when asserting next interaction; engine visual timing is separate QA.
    game.scare_timer = 0.0
    p.global_position = Vector2(790, 680)
    game.investigate()
    if not game.ending:
        _fail("Short demo ending was not reached")
        return
    print("SMOKE PASS: scene, movement, 4-dir sprite, phone, note, mirror, scare, ending")
    quit(0)

func _fail(message: String) -> void:
    push_error("SMOKE FAIL: " + message)
    quit(1)
