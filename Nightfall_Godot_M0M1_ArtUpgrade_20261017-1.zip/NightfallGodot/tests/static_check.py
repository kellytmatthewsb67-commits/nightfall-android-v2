"""Validate project structure and asset format, not Godot runtime or APK build."""
from pathlib import Path
from PIL import Image,ImageChops
import re,sys,wave
P=Path(__file__).resolve().parents[1];errors=[]

def verify(condition,msg):
    if not condition: errors.append(msg)
scene=(P/'scenes/main.tscn').read_text()
code=(P/'scripts/main.gd').read_text()
player=(P/'scripts/player.gd').read_text()
project=(P/'project.godot').read_text()
for s in re.findall(r'res://([^"\n]+)',scene+code+player+project):
    if '%' not in s:verify((P/s).exists(),f'Missing resource {s}')
verify(scene.count('type="Sprite2D"')>=5,'Scene missing actual textured layer nodes')
verify('CharacterBody2D' in scene and 'CollisionShape2D' in scene,'No character physical body')
verify('StaticBody2D.new()' in code,'No physical furniture/wall bodies')
verify('virtual_stick.gd' in code,'Mobile virtual joystick missing')
verify('SMOKE PASS' in (P/'tests/smoke_test.gd').read_text(),'No engine smoke test')
verify('export-debug Android' in (P/'.github/workflows/android-debug.yml').read_text(),'CI lacks APK export step')
verify('gl_compatibility' in project,'Mobile renderer not configured')
verify('window/handheld/orientation=0' in project,'Landscape orientation not selected')
verify((P/'art_source/illustrated_asset_board.png').exists(),'Missing original art board for reproducibility')
art=P/'assets/v2'
for direction in ('front','back','left','right'):
    for frame in range(4):
        f=art/f'hero_{direction}_{frame}.png'
        verify(f.exists(),f'Missing sprite {f.name}')
        if f.exists():
            with Image.open(f) as im:
                verify(im.mode=='RGBA',f'{f.name} lacks alpha channel')
                verify(im.getchannel('A').getextrema()[0]==0,f'{f.name} missing transparency')
                verify(im.getchannel('A').getbbox() is not None,f'{f.name} entirely transparent')
for p in art.glob('*.png'):
    try:
        with Image.open(p) as im:im.verify()
    except Exception as e:errors.append(f'Unreadable PNG: {p.name}: {e}')
for p in ['illustrated_room.png','ui_shell.png','side_portrait.png','scare_closeup.png','bed_foreground_layer.png','room_base.png']:
    verify((art/p).exists(),f'Missing rendered layer {p}')
try:
    with wave.open(str(art/'scare_stinger.wav'),'rb') as wav:
        verify(wav.getframerate()==44100 and wav.getnframes()>10000,'Scare WAV invalid')
except Exception as e:errors.append('WAV unreadable: '+str(e))
print('Static check:', 'PASS' if not errors else 'FAIL')
print('V2 image count:',len(list(art.glob('*.png'))))
for err in errors:print(' - '+err)
sys.exit(1 if errors else 0)
