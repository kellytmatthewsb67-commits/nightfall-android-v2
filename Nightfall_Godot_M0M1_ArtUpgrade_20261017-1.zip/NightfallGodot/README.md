# 夜幕之下：视线之外 — Godot 4.4.1 美术 / 引擎验证工程

**Current state: M0 未通过实际引擎验收；M1 美术整合候选工程，尚非 APK 或已验收游戏。**

这份是 **Godot 工程源文件**，不是 HTML 游戏，也没有假称已经生成 APK。包含绘制的室内游戏地图、女主角四方向 PNG 角色精灵、手机操作、碰撞和物品交互脚本、镜子异常恐怖事件与声音、静态自动化测试和远程 CI 安卓构建脚本。

## 快速查看实际资产（均为离线预览，非 Godot 运行截图）

- `docs/scene_asset_layout_preview_NOT_RUNTIME.png` — 依照 Godot 场景坐标和素材拼装的视觉检查图。
- `docs/sprite_4direction_qa.png` — 16 帧角色透明素材可视检查。
- `docs/separate_furniture_assets_qa.png` — 9 件独立家具/装饰 PNG。
- `docs/character_animation_preview.gif` — 角色帧轮播，**不是实机录屏**。
- `docs/QUALITY_GATE.md` — 当前哪些确实测过、哪些没测。

## 项目文件

- `project.godot`：Godot 项目入口，1280×720 横屏，GL Compatibility。
- `scenes/main.tscn`：主场景，世界层、角色物理体、床前景层、UI 底片。
- `scripts/main.gd`：互动、音效/突脸、状态、碰撞与手机 UI。
- `scripts/player.gd`：角色移动、四方向逐帧贴图切换。
- `scripts/virtual_stick.gd`：触屏摇杆控制。
- `assets/v2/`：本轮提取/重新设计的独立图像，含 16 帧游玩精灵、2 张正常身材比例人物设计参考、4 张表情头像、9 件家具、地图、前景遮挡、游戏 UI、恐怖 CG、安卓图标和短音效。
- `art_source/illustrated_asset_board.png`：美术生成母图，供二次切片、替换制作时参考。
- `tools/build_art_v2.py`：以 Pillow、OpenCV 和 NumPy 重新制作精灵与场景素材（构建已包含 PNG，不必先运行）。
- `tools/build_stage_v2.py`：地图区和 UI 层生成。
- `.github/workflows/android-debug.yml`：拟定 Android 自动构建，但尚未在实际仓库执行。

## 在已经安装 Godot 的计算机上测试

1. 用 **Godot 4.4.1** 导入此文件夹下 `project.godot`。
2. 导入完成后启动 `scenes/main.tscn`；PC `WASD` / 方向键移动，`E` 调查，`Shift` 跑；Android 画面左侧摇杆，右下角调查、奔跑。
3. 先检查手机、地上的纸条、镜子，重复调查镜子，然后从房间右下角离开。
4. 本地静态检查命令：`python tests/static_check.py && python tests/map_reachability.py`。
5. 已安装 Godot 的情况下，执行 `godot --headless --path . --editor --import --quit`、`godot --headless --path . --script res://tests/smoke_test.gd`。

## Android APK

工作流描述了如何在 GitHub Actions 安装匹配的 Godot 及导出模板、Java 和 Android SDK，并执行导入/烟测/导出。只有 workflow **成功运行** 且 APK **验证** 后才能宣称提供 Android 包。当前的环境中 **没有生成 APK**。

**未完成：** 完整独立家具地图、最终手工校正的角色逐帧动画、Godot 运行 / Android 验收。详见 `docs/QUALITY_GATE.md`。
