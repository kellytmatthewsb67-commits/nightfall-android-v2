# 《夜幕之下：视线之外》M0 / M1 Quality Gate

**Version:** visual-asset-iteration 2026-10-17. This is an **editable Godot source checkpoint**, NOT an Android-installed verified release.

## Evidence-based status

| Requirement | Result | Evidence |
|---|---|---|
| Project scene and scripts exist | Prepared, static-checked | `scenes/main.tscn`, `scripts/*.gd` |
| Illustrated hero sprites with alpha | Static PASS | 4 directions × 4 files under `assets/v2/hero_*` |
| Non-geometric protagonist | Asset inspection PASS | `docs/sprite_4direction_qa.png` |
| Full-body same-design reference | Available, NOT animated in gameplay | `assets/v2/hero_full_*_art_reference.png` |
| Bedroom staging legibility | Offline composition reviewed | `docs/scene_asset_layout_preview_NOT_RUNTIME.png` |
| Independent prop sprites | Asset inspection PASS | `docs/separate_furniture_assets_qa.png`; nine prop PNGs |
| Collision/interaction approach paths | Approximate static PASS | `tests/map_reachability.py` |
| Conditional mirror jumpscare / audio | Source implementation only | `scripts/main.gd`, WAV asset |
| Headless Godot import / script compile | **UNTESTED** | Godot binary unavailable in container |
| Headless Godot movement/interaction smoke | **UNTESTED** | `tests/smoke_test.gd` awaits Godot runtime |
| Android debug APK | **NOT BUILT** | Android SDK/Godot templates unavailable locally |
| Android phone gameplay/graphics/audio | **UNTESTED** | No device session or APK |
| Final professional four-direction hand animation | **NOT FINISHED** | Imported 4 source poses/direction are not verified final walk/run cycles |
| Entire bedroom as independent prop / wall / floor layers | **NOT FINISHED** | Center room still uses an illustrated map background; separate foreground and furniture sprites are supplied |

## Why M0 is still open

Godot 4.4.1 and the Android SDK were not installed locally, and external binary downloads were unavailable. Creating the GitHub Actions workflow **does not prove it ran**. The project must be imported and tested in a real Godot engine, then compiled to APK and tested on Android before M0 can pass. Until that point **no build or gameplay promises**.

## Actual M1 visual improvement

The source art includes a generated original illustrated asset board. Runtime-bound textures are saved as separate PNGs (protagonist 16 poses, portraits, main map, foreground bed occlusion, background, UI shell, icon, horror CG), and there are nine transparent prop pieces ready for continued proper layering. The room illustration still contains painted-in elements and must not be described as a completely layered tile map.

## Next work in required order

1. Use Godot 4.4.1 to run `--headless --editor --import --quit` and fix any import/GDScript errors.
2. Run `--headless --script res://tests/smoke_test.gd` and collect log.
3. Trigger an Android debug export in a configured SDK environment and confirm ZIP structure/APK signature.
4. On an actual Android phone: confirm landscape layout, touch movement, collisions, investigation, audio, and restart.
5. Before accepting M1: replace placeholder walk-cycle inbetweens with manually checked consistent drawn frames; split major furniture into accurate occlusion/collision layers.
