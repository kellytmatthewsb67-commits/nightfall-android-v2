"""Prepare illustrated map panel / separate UI art from generated board, no fake game screenshot."""
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
from pathlib import Path
P=Path(__file__).resolve().parents[1];A=P/'assets/v2'
src=Image.open(P/'art_source/illustrated_asset_board.png').convert('RGB')
room=src.crop((965,36,1328,571)).resize((520,720),Image.Resampling.LANCZOS)
room.save(A/'illustrated_room.png')
portrait=src.crop((12,141,302,573)).resize((375,558),Image.Resampling.LANCZOS)
portrait.save(A/'side_portrait.png')
# Occlusion mask of lower 20% of bed: overlay exact corresponding region of same map texture
# So a player walking north of bed is visually hidden by footboard, rather than standing above it.
# Object in original map: roughly source crop pixels x=115..238, y=290..493.
map_img=Image.open(A/'illustrated_room.png').convert('RGBA')
mask=Image.new('L',map_img.size,0);md=ImageDraw.Draw(mask)
md.rounded_rectangle((166,552,340,672),radius=9,fill=255)
mask=mask.filter(ImageFilter.GaussianBlur(3))
layer=Image.new('RGBA',map_img.size,(0,0,0,0));layer.paste(map_img,(0,0));layer.putalpha(mask)
layer.save(A/'bed_foreground_layer.png')
# Invisible editor image: no UI composition baked into map texture.
print('Illustrated map and overlay prepared:',room.size)

# Side panels / portrait are independent 1280x720 layers, composed by Godot at runtime.
from PIL import ImageFont
shell=Image.new('RGBA',(1280,720),(0,0,0,0));d=ImageDraw.Draw(shell,'RGBA')
d.rectangle((0,0,380,720),fill=(10,14,23,75))
d.rectangle((900,0,1280,720),fill=(11,15,24,245))
# subtle vertical red / brass edge details
for x in (370,377,900,904):
    d.line((x,0,x,720),fill=(131,92,85,155),width=2)
for x in (17,920):
    d.line((x,93,x+339,93),fill=(168,132,112,125),width=2)
    d.line((x,94,x+339,94),fill=(215,185,145,40),width=1)
for y in [18,694]:
    d.line((377,y,900,y),fill=(181,133,106,200),width=3)
d.rounded_rectangle((13,108,363,487),radius=8,outline=(178,135,116,118),width=2)
d.rounded_rectangle((921,178,1259,446),radius=10,fill=(24,24,33,155),outline=(135,108,101,140),width=2)
d.rounded_rectangle((921,463,1259,535),radius=9,fill=(19,24,32,175),outline=(118,95,89,100),width=2)
# Avatar photo beneath UI (not baked into shell)
shell.save(A/'ui_shell.png')
# Real application backdrop behind frame/portrait/map
back=Image.new('RGB',(1280,720),(8,11,17));ba=np.asarray(back).copy()
for y in range(720):
    ba[y,:,0]+=int(3*max(0,1-abs(y-450)/720))
    ba[y,:,2]+=int(6*max(0,1-abs(y-380)/720))
back=Image.fromarray(ba,'RGB');back.save(A/'stage_back.png')
print('Stage background / UI shell: independent ready')
