from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1]; A=P/'assets/v2'; D=P/'docs'
f='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font=lambda s:ImageFont.truetype(f,s)
img=Image.new('RGB',(1160,1120),(32,37,47));d=ImageDraw.Draw(img)
d.text((30,15),'女主角 · 四方向动态精灵素材',font=font(30),fill=(244,227,205))
rows=('front','back','left','right')
for i,name in enumerate(rows):
    d.text((28,90+i*210),{'front':'正面','back':'背面','left':'左侧','right':'右侧'}[name],font=font(23),fill=(217,200,187))
    for j in range(4):
        pic=Image.open(A/f'hero_{name}_{j}.png').convert('RGBA')
        pic=pic.resize((152,184),Image.Resampling.LANCZOS)
        x=190+j*212;y=72+i*210
        d.rounded_rectangle((x-12,y-4,x+164,y+194),radius=10,fill=(78,83,91),outline=(139,119,110),width=2)
        img.paste(pic,(x,y),pic)
d.text((28,948),'静止 / 踏步 / 过渡 / 奔跑  •  独立透明 PNG，可直接导入游戏',font=font(20),fill=(222,208,191))
img.save(D/'sprite_4direction_qa.png')
# Transparent prop atlas preflight
p=Image.new('RGB',(1000,610),(41,47,58));d=ImageDraw.Draw(p)
for idx,name in enumerate(('bed','bookcase','window','mirror','rug','door','painting','plant','wall_table')):
    col,row=idx%3,idx//3;x=col*330+15;y=row*200+10
    d.rounded_rectangle((x,y,x+310,y+189),radius=10,fill=(77,82,90),outline=(132,115,104),width=2)
    s=Image.open(A/(name+'.png')).convert('RGBA');s.thumbnail((275,150),Image.Resampling.LANCZOS)
    p.paste(s,(x+155-s.width//2,y+9),s)
    d.text((x+18,y+157),name,font=font(20),fill=(241,227,210))
p.save(D/'separate_furniture_assets_qa.png')
# Actual image frames as GIF animation preview; asset cycling, not Godot recording.
frames=[]
for k in range(16):
    phase=k%4;dirn=['front','left','back','right'][(k//4)%4]
    c=Image.new('RGB',(300,244),(51,56,65));dc=ImageDraw.Draw(c)
    for line in range(0,300,24):dc.line((line,0,line,244),fill=(62,67,75))
    dc.line((0,210,300,210),fill=(190,154,129),width=3)
    s=Image.open(A/f'hero_{dirn}_{phase}.png').convert('RGBA')
    s=s.resize((168,205),Image.Resampling.LANCZOS)
    c.paste(s,(68+(phase%2)*4,0),s)
    dc.text((12,215),dirn+'/'+str(phase),font=font(16),fill='white')
    frames.append(c)
frames[0].save(D/'character_animation_preview.gif',save_all=True,append_images=frames[1:],duration=135,loop=0,optimize=False)
print('Art QA sheets and GIF complete')
