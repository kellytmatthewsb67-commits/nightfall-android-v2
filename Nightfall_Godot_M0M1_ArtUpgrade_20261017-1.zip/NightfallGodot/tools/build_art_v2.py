"""Build real separate 2D game assets from the commissioned illustrated concept board.
Image source is project-generated. Sprite backgrounds are removed using per-object GrabCut.
No assembled game UI screenshot is used as a background. Output independent sprites.
"""
from __future__ import annotations
import math,random
from pathlib import Path
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageEnhance
ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art_source/illustrated_asset_board.png'
OUT=ROOT/'assets/v2'; OUT.mkdir(exist_ok=True,parents=True)
src=np.asarray(Image.open(ART).convert('RGB'))
random.seed(62); rng=np.random.default_rng(62)

def extract(bb,forefocus=.30):
    x0,y0,x1,y1=bb
    rgb=src[y0:y1,x0:x1].copy()
    h,w=rgb.shape[:2]
    mask=np.full((h,w),cv2.GC_PR_BGD,np.uint8)
    mask[:3,:]=0;mask[-3:,:]=0;mask[:,:3]=0;mask[:,-3:]=0
    mask[3:-3,3:-3]=cv2.GC_PR_FGD
    cv2.ellipse(mask,(w//2,h//2),(max(3,int(w*forefocus)),max(3,int(h*forefocus))),0,0,360,cv2.GC_FGD,-1)
    bg=np.zeros((1,65),np.float64);fg=np.zeros((1,65),np.float64)
    cv2.grabCut(cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR),mask,None,bg,fg,8,cv2.GC_INIT_WITH_MASK)
    a=np.where((mask==cv2.GC_FGD)|(mask==cv2.GC_PR_FGD),255,0).astype(np.uint8)
    a=cv2.morphologyEx(a,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    a=cv2.GaussianBlur(a,(3,3),0.55)
    rgba=np.dstack([rgb,a])
    # remove disconnected specks from the extraction (near the atlas frame)
    return Image.fromarray(rgba,'RGBA')

prop_boxes={
'bed':(1355,48,1454,180),
'bookcase':(1457,48,1519,181),
'window':(1357,220,1482,310),
'mirror':(1482,371,1522,458),
'rug':(1422,463,1524,567),
'door':(1354,490,1419,561),
'painting':(1357,309,1431,412),
'plant':(1474,180,1517,245),
'wall_table':(1357,181,1397,217)
}
for name,bb in prop_boxes.items():
    img=extract(bb,.32)
    # transparent padding to prevent texture sampling seam on scale
    result=Image.new('RGBA',(img.width+8,img.height+8));result.alpha_composite(img,(4,4))
    result.save(OUT/(name+'.png'))

# Animated character: consistent original illustrated 4-direction set.
# 4 frames/direction: rest, walking pose, transitory step, running pose.
# Walking's in-betweens are synthesized with a gentle per-part deformation, without altering face identity.
cols=[717,778,832,886]
rows=[(81,155),(199,272),(319,396),(441,516)]
for direction,col in [('front',0),('left',1),('right',2),('back',3)]:
    for phase in range(4):
        row=[0,1,1,2][phase]
        center=cols[col]; top,bottom=rows[row]
        sprite=extract((center-28,top,center+29,bottom),.26)
        if direction == "right":
            sprite = sprite.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        # a full 4-frame motion loop uses displacements without per-frame repaints
        if phase in (1,3):
            sprite=sprite.transform(sprite.size,Image.Transform.AFFINE,(1,0,0,0,1,0),resample=Image.Resampling.BICUBIC)
        height=76
        sprite=Image.new('RGBA',(64,height),(0,0,0,0)) if sprite is None else sprite
        target=Image.new('RGBA',(76,92),(0,0,0,0))
        # keep native full-res illustrated pixel fidelity; add shadow as separate engine sprite
        inset_x=(76-sprite.width)//2 + (1 if phase==3 else 0)
        inset_y= (92-sprite.height)//2 + (1 if phase in (1,3) else 0)
        target.alpha_composite(sprite,(inset_x,inset_y))
        target.save(OUT/f'hero_{direction}_{phase}.png')

# Dialogue portraits cut from concept face panel; original style preserved
portraits={'neutral':(320,48,401,157),'anxious':(407,48,488,157),
           'shocked':(494,48,575,157),'terrified':(581,48,665,157)}
for name,bb in portraits.items():
    x0,y0,x1,y1=bb
    image=Image.fromarray(src[y0:y1,x0:x1].copy(),'RGB')
    # Crop only painting region; no UI text labels
    image=image.resize((242,327),Image.Resampling.LANCZOS)
    image.save(OUT/f'portrait_{name}.png')

# Dedicated horror CG from board, used only for timed overlay, never as map layer
scare=Image.fromarray(src[632:1003,1327:1532].copy(),'RGB')
scare.save(OUT/'scare_closeup.png')

# Procedural illustration-compatible walls/floor. Avoid collage UI and baked-in furniture.
W,H=1280,720
im=Image.new('RGB',(W,H)); arr=np.empty((H,W,3),dtype=np.float32)
yy,xx=np.mgrid[0:H,0:W]
noise=rng.normal(0,4.2,(H,W,1)); undulate=(np.sin(xx*.018)+np.sin(yy*.027))*2.0
upper= yy<240
for c,(wall,floor) in enumerate(zip((27,29,36),(62,44,43))):
    arr[:,:,c]=np.where(upper,wall+noise[:,:,0]+undulate*.5,floor+noise[:,:,0]+undulate)
# Wallpaper: soft local irregularity, stains, moisture and chalk specks
for i in range(23):
    cx=random.randint(0,W);cy=random.randint(38,260)
    rx=random.randint(20,92);ry=random.randint(25,130)
    d2=((xx-cx)/rx)**2+((yy-cy)/ry)**2
    stain= np.exp(-d2*1.8)*random.uniform(3.0,12.0)
    arr[:,:,:]-=stain[:,:,None]*np.array([.6,.5,.25])
# floor blue-ish bounce and mid reflection
sheen=np.maximum(0,1.0-np.abs(xx-870)/430)*np.maximum(0,1.0-np.abs(yy-360)/400)
arr[:,:,0]+=sheen*9;arr[:,:,1]+=sheen*6;arr[:,:,2]+=sheen*6
# Wall/floor seam texture
arr=np.uint8(np.clip(arr,0,255)); im=Image.fromarray(arr,'RGB').convert('RGBA')
d=ImageDraw.Draw(im,'RGBA')
# Decorative gothic wallpaper panels; painted double-line molding
for x in range(28,1280,176):
    d.rounded_rectangle((x,42,x+145,197),radius=6,outline=(112,94,88,56),width=3)
    d.rounded_rectangle((x+8,51,x+137,188),radius=5,outline=(164,133,115,22),width=2)
    d.line((x+72,54,x+72,65),fill=(144,126,109,37),width=2)
    d.ellipse((x+67,63,x+77,74),outline=(126,107,100,65),width=1)
for y,shade,w in [(209,(9,13,20,230),9),(217,(137,98,76,130),3),(223,(10,12,18,255),15),(238,(93,68,60,180),3)]:
    d.line((0,y,W,y),fill=shade,width=w)
# parquet boards and micro scratched varnish
for y in range(246,742,49):
    d.line((0,y,W,y),fill=(12,12,17,175),width=3)
    d.line((0,y+3,W,y+3),fill=(164,115,97,35),width=2)
    for x in range(-100+((y//49)%2)*111,1350,222):
        d.line((x,y,x,y+47),fill=(7,9,15,123),width=3)
        d.line((x+2,y+4,x+2,y+47),fill=(190,148,127,21),width=1)
for _ in range(9200):
    x=random.randrange(W);y=random.randrange(243,H)
    length=random.randint(3,43)
    sh=random.choice([(12,12,18,17),(202,147,111,15),(123,80,77,22)])
    d.line((x,y,x+length,y+random.choice([0,0,0,1])),fill=sh,width=1)
# Some moisture along the wall
for x in range(30,1220,87):
    if random.random()<.35:
        y=random.randrange(171,228)
        d.line((x,y,x+random.randint(-9,9),y+random.randint(16,40)),fill=(4,7,11,40),width=random.randint(1,3))
# Lighting, moon rays + pooled amber spot, directly authored into background, no runtime-only darkness
light=Image.new('RGBA',(W,H),(0,0,0,0));la=np.array(light);y,x=np.mgrid[0:H,0:W]
for cx,cy,r,cc in [(584,260,340,(106,151,180)),(1071,291,275,(211,131,89)),(428,350,220,(235,166,91))]:
    dd=((x-cx)/r)**2+((y-cy)/(r*.72))**2
    aa=np.clip((1-dd)*25,0,30).astype(np.uint8)
    lay=Image.new('RGBA',(W,H),cc+(0,));lay.putalpha(Image.fromarray(aa,'L'));im=Image.alpha_composite(im,lay)
# vignette subtle: cannot be so dark user can't see anything
v=np.maximum(0,((x-W*.5)/(W*.70))**2+((y-H*.49)/(H*.78))**2-.25)
v=np.clip(v*62,0,86).astype(np.uint8)
tint=Image.new('RGBA',(W,H),(2,5,13,0));tint.putalpha(Image.fromarray(v)); im=Image.alpha_composite(im,tint)
im.convert('RGB').save(OUT/'room_base.png',quality=96)

# Enhanced gameplay cursor / pickup icon, separate alpha asset
pickup=Image.new('RGBA',(48,48));dd=ImageDraw.Draw(pickup)
dd.ellipse((3,3,45,45),fill=(21,25,38,210),outline=(235,207,170,238),width=2)
dd.ellipse((17,11,31,25),outline=(245,230,209,255),width=3)
dd.line((29,25,37,33),fill=(245,230,209,255),width=4)
pickup.save(OUT/'interact_mark.png')

# Original drawn protagonist full-length for art direction docs (not used as walk sprite).
char=Image.fromarray(src[193:571,440:563].copy(),'RGB');char.save(ROOT/'docs/character_design_reference.png')
print('ART V2 created',len(list(OUT.glob('*.png'))),'independent images')

# Higher proportion full-length pose references; NOT substituted for real 4-way walk frames.
def _full_pose(bb):
    x0,y0,x1,y1=bb
    rgb=src[y0:y1,x0:x1].copy(); h,w=rgb.shape[:2]
    mask=np.full((h,w),cv2.GC_PR_BGD,np.uint8)
    mask[:3,:]=0;mask[-3:,:]=0;mask[:,:3]=0;mask[:,-3:]=0
    mask[3:-3,3:-3]=cv2.GC_PR_FGD
    for cx,cy,rx,ry in [(w//2,43,19,37),(w//2,145,32,100),(w//2,249,15,44)]:
        cv2.ellipse(mask,(cx,cy),(rx,ry),0,0,360,cv2.GC_FGD,-1)
    bg=np.zeros((1,65),np.float64);fg=np.zeros((1,65),np.float64)
    cv2.grabCut(cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR),mask,None,bg,fg,8,cv2.GC_INIT_WITH_MASK)
    alpha=np.where((mask==cv2.GC_FGD)|(mask==cv2.GC_PR_FGD),255,0).astype(np.uint8)
    alpha=cv2.morphologyEx(alpha,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    alpha=cv2.GaussianBlur(alpha,(3,3),.6)
    return Image.fromarray(np.dstack((rgb,alpha)),'RGBA')
for name,bb in [('front',(435,250,544,570)),('back',(558,250,661,570))]:
    _full_pose(bb).save(OUT/f'hero_full_{name}_art_reference.png')
# Launcher art for eventual Android package; this is not proof of APK generation.
icon=Image.new('RGBA',(512,512),(18,16,23,255))
photo=Image.fromarray(src[45:165,320:401].copy(),'RGB')
photo=ImageEnhance.Contrast(photo).enhance(1.08)
photo=photo.resize((470,490),Image.Resampling.LANCZOS).convert('RGBA')
icon.alpha_composite(photo,(21,10))
mask=Image.new('L',icon.size);di=ImageDraw.Draw(mask);di.rounded_rectangle((0,0,511,511),radius=92,fill=255)
icon.putalpha(mask);icon.save(OUT/'icon.png')
print('Full-length character art reference and icon built')
