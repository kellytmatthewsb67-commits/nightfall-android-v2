"""Offline scene-layout preview using EXACT textures and Godot node coordinates.
NOT a Godot runtime screenshot, and does not validate import, input or APK build.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter
P=Path(__file__).resolve().parents[1];A=P/'assets/v2'
base=Image.open(A/'stage_back.png').convert('RGBA')
def put(name,x,y,scale=1):
    global base
    img=Image.open(A/(name+'.png')).convert('RGBA')
    if scale != 1:img=img.resize((round(img.width*scale),round(img.height*scale)),Image.Resampling.LANCZOS)
    base.alpha_composite(img,(x,y))
put('side_portrait',0,116)
put('illustrated_room',380,0)
# player sprite node pos (663,347), with offset -46 and scale .79
img=Image.open(A/'hero_front_0.png').convert('RGBA');img=img.resize((90,109),Image.Resampling.LANCZOS)
base.alpha_composite(img,(663-45,347-109))
put('ui_shell',0,0)
f='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font=lambda n:ImageFont.truetype(f,n)
d=ImageDraw.Draw(base)
d.text((23,15),'夜 幕 之 下',font=font(33),fill=(246,226,204))
d.text((23,67),'N I G H T F A L L   /   02:17',font=font(13),fill=(198,169,163))
d.text((22,456),'澪  ·  不要回头',font=font(23),fill=(245,224,211))
d.text((933,27),'探索记录',font=font(22),fill=(245,220,193))
d.text((934,108),'寻找房间中的异常',font=font(20),fill=(221,201,188))
d.text((934,137),'调查手机与镜子',font=font(20),fill=(221,201,188))
d.text((935,193),'调查记录',font=font(21),fill=(233,215,199))
d.text((936,232),'02:17。',font=font(20),fill=(238,220,207))
d.text((936,273),'一声敲击，来自',font=font(19),fill=(238,220,207))
d.text((936,306),'没有门的那面墙。',font=font(19),fill=(238,220,207))
d.text((936,473),'线索  0 / 2',font=font(19),fill=(207,185,178))
d.text((936,520),'WASD移动 · E调查',font=font(16),fill=(189,174,171))
# approximate same joystick geometry as Control._draw
for x,y,r in [(118,606,82),(1086,653,45),(1195,644,53)]:
 d.ellipse((x-r,y-r,x+r,y+r),fill=(18,24,36,168),outline=(172,164,161,155),width=2)
d.ellipse((88,573,148,633),fill=(126,143,159),outline=(230,214,197),width=2)
d.text((1060,640),'奔跑',font=font(18),fill=(239,222,209))
d.text((1172,631),'调查',font=font(20),fill=(240,224,211))
# Not a runtime screenshot: conspicuous exterior bottom tag in documentation version only
base.convert('RGB').save(P/'docs/scene_asset_layout_preview_NOT_RUNTIME.png')
print('Wrote docs/scene_asset_layout_preview_NOT_RUNTIME.png')
