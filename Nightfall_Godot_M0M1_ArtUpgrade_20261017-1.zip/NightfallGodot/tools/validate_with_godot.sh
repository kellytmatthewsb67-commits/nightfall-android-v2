#!/usr/bin/env bash
# Only declare M0 success if this script passes with a REAL Godot 4.4.1 binary.
set -euo pipefail
GODOT_BIN="${GODOT_BIN:-godot}"
cd "$(dirname "$0")/.."
python3 tests/static_check.py
python3 tests/map_reachability.py
if ! command -v "$GODOT_BIN" >/dev/null 2>&1; then
  echo 'NOT VERIFIED: Godot executable unavailable. This is NOT a passing M0 gate.' >&2
  exit 2
fi
"$GODOT_BIN" --version
"$GODOT_BIN" --headless --path . --editor --import --quit | tee build/godot-import.log
if grep -Ei '^SCRIPT ERROR:|^ERROR:' build/godot-import.log; then
  echo 'FAIL: Godot import or script error.' >&2
  exit 1
fi
if [[ "${EXPORT_ANDROID:-0}" == "1" ]]; then
  "$GODOT_BIN" --headless --path . --export-debug Android build/Nightfall-M1-debug.apk
  test -s build/Nightfall-M1-debug.apk
  unzip -t build/Nightfall-M1-debug.apk
fi
