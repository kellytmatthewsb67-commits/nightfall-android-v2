"""Offline layered-scene visual preflight. This is NOT a Godot runtime screenshot."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter
P=Path(__file__).resolve().parents[1]; A=P/'assets/v2'
base=Image.open(A/'room_base.png').convert('RGBA')
placements=[
 ('painting',(240,151),2.05,'center'),('window',(610,137),2.05,'center'),
 ('door',(1104,171),2.13,'center'),('rug',(656,600),2.55,'center'),
 ('bookcase',(138,442),2.15,'bottom'),('wall_table',(391,410),3.85,'bottom'),
 ('plant',(1005,431),2.22,'bottom'),('mirror',(1130,439),2.02,'bottom'),
 ('bed',(856,674),2.18,'bottom'),('hero_front_0',(648,597),1.18,'bottom')]
for name,(px,py),scale,anchor in placements:
 img=Image.open(A/(name+'.png')).convert('RGBA')
 img=img.resize((round(img.width*scale),round(img.height*scale)),Image.Resampling.LANCZOS)
 x=int(px-img.width/2);y=int(py-img.height if anchor=='bottom' else py-img.height/2)
 base.alpha_composite(img,(x,y))
base.convert('RGB').save(P/'docs/visual_preflight_no_ui.png')
print('Created rendered source-layer composite; not gameplay screenshot')
